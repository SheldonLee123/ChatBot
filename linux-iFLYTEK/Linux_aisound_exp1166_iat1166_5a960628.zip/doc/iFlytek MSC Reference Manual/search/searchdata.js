var indexSectionsWithContent =
{
  0: "mq",
  1: "mq",
  2: "mq"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "全部",
  1: "文件",
  2: "函数"
};

